# Cat Dog Detector > 2024-05-03 2:34am
https://universe.roboflow.com/yolo-course/cat-dog-detector-exnoj

Provided by a Roboflow user
License: CC BY 4.0

